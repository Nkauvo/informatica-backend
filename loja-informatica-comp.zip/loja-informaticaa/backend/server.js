const express = require('express');
const cors = require('cors');
require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware CORS
app.use(cors({
  origin: 'http://127.0.0.1:5500' // Permite o acesso do frontend
}));

app.use(express.json());

// Inicializar o cliente Supabase
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

// Rota inicial de teste
app.get('/', (req, res) => {
  res.json({ mensagem: 'API rodando!' });
});

// Rota GET - Buscar todos os produtos
app.get('/produtos', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('produtos')
      .select('*');  // Seleciona todos os produtos

    if (error) throw error;
    res.json(data);  // Retorna os produtos

  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

// Rota GET - Buscar produto por ID
app.get('/produtos/:id', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('produtos')
      .select('*')
      .eq('id', req.params.id)  // Filtra pelo ID
      .single();  // Retorna um único produto

    if (error) throw error;
    res.json(data);  // Retorna o produto encontrado

  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

// Rota POST - Criar um novo produto
app.post('/produtos', async (req, res) => {
  try {
    const { nome, preco } = req.body;  // Extrai os dados do corpo da requisição

    const { data, error } = await supabase
      .from('produtos')
      .insert([{ nome, preco }]);  // Insere o novo produto na tabela

    if (error) throw error;
    res.status(201).json(data);  // Retorna os dados do produto inserido

  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

// Rota PUT - Atualizar produto
app.put('/produtos/:id', async (req, res) => {
  try {
    const { nome, preco } = req.body;  // Extrai os dados do corpo da requisição

    const { data, error } = await supabase
      .from('produtos')
      .update({ nome, preco })
      .eq('id', req.params.id)
      .single();  // Atualiza o produto com base no ID

    if (error) throw error;
    res.json(data);  // Retorna o produto atualizado

  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

// Rota DELETE - Deletar produto
app.delete('/produtos/:id', async (req, res) => {
  try {
    const { error } = await supabase
      .from('produtos')
      .delete()
      .eq('id', req.params.id);  // Deleta o produto com base no ID

    if (error) throw error;

    res.json({ mensagem: 'Produto deletado com sucesso!' });  // Confirma a exclusão

  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
